using Microsoft.AspNetCore.Mvc;
using PigGameApp.Models;
using System.Diagnostics;

namespace PigGameApp.Controllers
{
    public class HomeController : Controller
    {
        // Main game screen
        public IActionResult Index()
        {
            // If the session is not initialized, start a new game
            if (HttpContext.Session.GetString("CurrentPlayer") == null)
            {
                return RedirectToAction("NewGame");
            }

            // Pass game data to the view
            ViewData["Player1Score"] = HttpContext.Session.GetInt32("Player1Score");
            ViewData["Player2Score"] = HttpContext.Session.GetInt32("Player2Score");
            ViewData["TurnScore"] = HttpContext.Session.GetInt32("TurnScore");
            ViewData["DieValue"] = HttpContext.Session.GetInt32("DieValue");
            ViewData["CurrentPlayer"] = HttpContext.Session.GetString("CurrentPlayer");
            ViewData["Winner"] = HttpContext.Session.GetString("Winner") ?? ""; // Explicitly set to empty if null

            return View();
        }

        // Start a new game
        public IActionResult NewGame()
        {
            HttpContext.Session.SetInt32("Player1Score", 0);
            HttpContext.Session.SetInt32("Player2Score", 0);
            HttpContext.Session.SetInt32("TurnScore", 0);
            HttpContext.Session.SetInt32("DieValue", 0);
            HttpContext.Session.SetString("CurrentPlayer", "Player1");
            HttpContext.Session.SetString("Winner", ""); // Initialize Winner as empty

            return RedirectToAction("Index");
        }

        // Roll the die
        public IActionResult Roll()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("Winner")))
            {
                string currentPlayer = HttpContext.Session.GetString("CurrentPlayer");
                int turnScore = HttpContext.Session.GetInt32("TurnScore") ?? 0;

                // Generate a random die value between 1 and 6
                Random random = new Random();
                int dieValue = random.Next(1, 7);
                HttpContext.Session.SetInt32("DieValue", dieValue);

                if (dieValue == 1)
                {
                    // If die rolls 1, reset turn score and switch player
                    HttpContext.Session.SetInt32("TurnScore", 0);
                    SwitchPlayer();
                }
                else
                {
                    // Otherwise, add die value to the turn score
                    HttpContext.Session.SetInt32("TurnScore", turnScore + dieValue);
                }

                // Check if the current player has won after this roll
                int currentPlayerScore = currentPlayer == "Player1" ? HttpContext.Session.GetInt32("Player1Score") ?? 0 : HttpContext.Session.GetInt32("Player2Score") ?? 0;

                // If player reaches or exceeds 20, declare the winner
                if (currentPlayerScore + turnScore >= 20)
                {
                    // Update the player's score before declaring the winner
                    if (currentPlayer == "Player1")
                    {
                        HttpContext.Session.SetInt32("Player1Score", currentPlayerScore + turnScore);
                    }
                    else if (currentPlayer == "Player2")
                    {
                        HttpContext.Session.SetInt32("Player2Score", currentPlayerScore + turnScore);
                    }

                    // Set the winner and reset the turn score
                    HttpContext.Session.SetString("Winner", currentPlayer == "Player1" ? "Player 1" : "Player 2");
                    HttpContext.Session.SetInt32("TurnScore", 0); // Reset turn score
                    HttpContext.Session.SetInt32("DieValue", 0);  // Reset die value
                }
            }

            return RedirectToAction("Index");
        }

        // Hold the current turn score
        public IActionResult Hold()
        {
            if (!string.IsNullOrEmpty(HttpContext.Session.GetString("Winner")))
            {
                return RedirectToAction("Index"); // Stop if there's already a winner
            }

            // Retrieve current player and scores
            string currentPlayer = HttpContext.Session.GetString("CurrentPlayer");
            int turnScore = HttpContext.Session.GetInt32("TurnScore") ?? 0;

            if (currentPlayer == "Player1")
            {
                int player1Score = HttpContext.Session.GetInt32("Player1Score") ?? 0;
                player1Score += turnScore; // Add turn score to player 1's total
                HttpContext.Session.SetInt32("Player1Score", player1Score);

                if (player1Score >= 20) // Check if Player 1 wins
                {
                    HttpContext.Session.SetString("Winner", "Player 1");
                    HttpContext.Session.SetInt32("TurnScore", 0); // Reset turn score
                    return RedirectToAction("Index"); // End the game
                }
            }
            else if (currentPlayer == "Player2")
            {
                int player2Score = HttpContext.Session.GetInt32("Player2Score") ?? 0;
                player2Score += turnScore; // Add turn score to player 2's total
                HttpContext.Session.SetInt32("Player2Score", player2Score);

                if (player2Score >= 20) // Check if Player 2 wins
                {
                    HttpContext.Session.SetString("Winner", "Player 2");
                    HttpContext.Session.SetInt32("TurnScore", 0); // Reset turn score
                    return RedirectToAction("Index"); // End the game
                }
            }

            // Reset turn score and switch player if no winner
            HttpContext.Session.SetInt32("TurnScore", 0); // Reset turn score
            HttpContext.Session.SetInt32("DieValue", 0);  // Reset die value

            if (string.IsNullOrEmpty(HttpContext.Session.GetString("Winner")))
            {
                SwitchPlayer(); // Only switch player if there's no winner
            }

            return RedirectToAction("Index");
        }

        // Switch to the next player
        private void SwitchPlayer()
        {
            string currentPlayer = HttpContext.Session.GetString("CurrentPlayer");
            HttpContext.Session.SetString("CurrentPlayer", currentPlayer == "Player1" ? "Player2" : "Player1");
        }
    }
}
