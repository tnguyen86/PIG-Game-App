var builder = WebApplication.CreateBuilder(args);

// Add session state services
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Session expires after 30 minutes of inactivity
    options.Cookie.HttpOnly = true; // Cookie cannot be accessed via JavaScript
    options.Cookie.IsEssential = true; // Required even if cookie consent policies are in place
});

builder.Services.AddControllersWithViews();

var app = builder.Build();

app.UseStaticFiles(); // Serve static files like CSS
app.UseRouting();
app.UseSession(); // Enable session state middleware

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();